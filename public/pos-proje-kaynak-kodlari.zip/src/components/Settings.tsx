import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, updateDoc, doc, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Settings as SettingsIcon, Shield, UserCheck, Mail, Download, Globe, CheckCircle2, FileArchive, Server } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Subscription } from './Subscription';

const Settings: React.FC = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [newEmail, setNewEmail] = useState('');
  const [newStatus, setNewStatus] = useState('inactive');
  const { role: currentUserRole } = useAuth();

  useEffect(() => {
    if (currentUserRole !== 'admin') return;
    const unsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, [currentUserRole]);

  const toggleRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'admin' ? 'staff' : 'admin';
    await updateDoc(doc(db, 'users', userId), { role: newRole });
  };

  const updateSubscriptionStatus = async (userId: string, newStatus: string) => {
    await updateDoc(doc(db, 'users', userId), { subscriptionStatus: newStatus });
  };

  const addMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail) return;
    
    await addDoc(collection(db, 'users'), {
      email: newEmail,
      role: 'staff',
      subscriptionStatus: newStatus,
      createdAt: new Date()
    });

    await addDoc(collection(db, 'mail'), {
      to: newEmail,
      message: {
        subject: 'Uygulamamıza Hoş Geldiniz',
        text: 'Sisteme personel olarak eklendiniz. Uygulamaya giriş yapabilirsiniz.',
        html: '<p>Sisteme personel olarak eklendiniz. Uygulamaya giriş yapabilirsiniz.</p>'
      }
    });

    setNewEmail('');
    setNewStatus('inactive');
  };

  return (
    <div className="p-3 sm:p-4 lg:p-8 space-y-4 lg:space-y-6 max-w-4xl mx-auto">
      <header className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm group">
          <SettingsIcon className="w-5 h-5 transition-transform group-hover:rotate-90" />
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">Sistem Ayarları</h2>
          <p className="text-slate-500 text-xs sm:text-sm mt-0.5">Kullanıcı yetkilendirme ve uygulama yapılandırması.</p>
        </div>
      </header>

      <div className="max-w-2xl bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center gap-3">
          <Mail className="w-5 h-5 text-blue-600" />
          <h3 className="font-bold text-slate-900">Yeni Üye Ekle</h3>
        </div>
        <form onSubmit={addMember} className="p-6 border-b border-slate-100 flex gap-2">
          <input 
            type="email" 
            value={newEmail}
            onChange={(e) => setNewEmail(e.target.value)}
            placeholder="Üye E-posta Adresi"
            className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm"
          />
          <select 
            value={newStatus}
            onChange={(e) => setNewStatus(e.target.value)}
            className="px-2 py-1 border border-slate-200 rounded-lg text-sm"
          >
            <option value="inactive">Pasif</option>
            <option value="trial">Deneme</option>
            <option value="active">Aktif</option>
          </select>
          <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold">EKLE</button>
        </form>
        <div className="p-6 border-b border-slate-100 flex items-center gap-3">
          <Shield className="w-5 h-5 text-blue-600" />
          <h3 className="font-bold text-slate-900">Kullanıcı Yetkileri ve Abonelik</h3>
        </div>
        <div className="divide-y divide-slate-100">
          {users.map(user => (
            <div key={user.id} className="p-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold">
                  {user.email?.substring(0, 1).toUpperCase()}
                </div>
                <div>
                  <p className="font-medium text-slate-900">{user.email}</p>
                  <p className="text-xs text-slate-500 flex items-center gap-1">
                    <UserCheck className="w-3 h-3" />
                    Rol: <span className="capitalize font-bold text-blue-600">{user.role === 'admin' ? 'Yönetici' : 'Personel'}</span>
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <select 
                  value={user.subscriptionStatus || 'inactive'}
                  onChange={(e) => updateSubscriptionStatus(user.id, e.target.value)}
                  className="px-2 py-1 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 bg-slate-50"
                >
                  <option value="inactive">Pasif</option>
                  <option value="trial">Deneme</option>
                  <option value="active">Aktif</option>
                </select>
                <button 
                  onClick={() => toggleRole(user.id, user.role)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-xs font-bold hover:bg-slate-50 transition-colors"
                >
                  ROLÜ DEĞİŞTİR
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Canlıya Alma ve ZIP İndirme Bölümü */}
      <div className="max-w-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-xl shadow-lg overflow-hidden border border-slate-700">
        <div className="p-6 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">Canlıya Alma & ZIP Dosyaları</h3>
              <p className="text-xs text-slate-400">pos.beyoglukirtasiye.tr veya hostinginiz için hazır paketler</p>
            </div>
          </div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3.5 h-3.5" /> Canlıya Hazır
          </span>
        </div>

        <div className="p-6 space-y-4">
          <p className="text-sm text-slate-300 leading-relaxed">
            Sisteminizi kendi alan adınızda (<span className="text-emerald-400 font-mono font-semibold">pos.beyoglukirtasiye.tr</span>) yayınlamak için hazırlanmış ZIP paketlerini aşağıdan tek tıkla indirebilirsiniz. 
            Verileriniz Firebase bulut veritabanına bağlı olduğu için siteden eklediğiniz tüm ürünler, satışlar ve stoklar her yerden eş zamanlı (canlı) çalışır.
          </p>

          <div className="grid sm:grid-cols-2 gap-3 pt-2">
            {/* Canlı Yayın Paketi (dist.zip) */}
            <a
              href="/pos-canli-web-dist.zip"
              download="pos-canli-web-dist.zip"
              className="flex flex-col justify-between p-4 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-emerald-500/40 hover:border-emerald-400 transition-all group"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5 text-emerald-400 font-bold text-sm">
                  <Server className="w-4 h-4" />
                  <span>Canlı Yayın Paketi</span>
                </div>
                <Download className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-xs text-slate-400 mt-2">
                cPanel / Plesk / Nginx / Apache public_html içine doğrudan çıkartılacak hazır HTML+JS dosyaları ve .htaccess.
              </p>
              <div className="mt-3 pt-2 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-emerald-300 font-medium">
                <span>pos-canli-web-dist.zip</span>
                <span className="bg-emerald-500/20 px-2 py-0.5 rounded font-mono">1.6 MB</span>
              </div>
            </a>

            {/* Tüm Kaynak Kodları (source.zip) */}
            <a
              href="/pos-proje-kaynak-kodlari.zip"
              download="pos-proje-kaynak-kodlari.zip"
              className="flex flex-col justify-between p-4 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 hover:border-slate-550 transition-all group"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5 text-blue-400 font-bold text-sm">
                  <FileArchive className="w-4 h-4" />
                  <span>Kaynak Kodları</span>
                </div>
                <Download className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-xs text-slate-400 mt-2">
                Tüm React + Vite + TypeScript proje dosyaları, bileşenler ve konfigürasyonlar.
              </p>
              <div className="mt-3 pt-2 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-blue-300 font-medium">
                <span>pos-proje-kaynak-kodlari.zip</span>
                <span className="bg-blue-500/20 px-2 py-0.5 rounded font-mono">1.3 MB</span>
              </div>
            </a>
          </div>

          {/* Hızlı Kurulum Adımları */}
          <div className="mt-4 p-4 rounded-lg bg-slate-800/50 border border-slate-700/70 text-xs text-slate-300 space-y-2">
            <p className="font-semibold text-white flex items-center gap-1.5">
              <span>🚀</span> pos.beyoglukirtasiye.tr için 3 Adımda Canlıya Alma:
            </p>
            <ol className="list-decimal list-inside space-y-1 text-slate-400 leading-relaxed">
              <li>Yukarıdaki <b className="text-emerald-400 font-medium">Canlı Yayın Paketi (.zip)</b> butonuna basarak zip dosyasını indirin.</li>
              <li>Hostinginizin (cPanel / Plesk) Dosya Yöneticisine girip <code className="bg-slate-900 px-1.5 py-0.5 rounded text-emerald-300">pos.beyoglukirtasiye.tr</code> klasörüne gidin.</li>
              <li>Zip dosyasını yükleyip <b className="text-white">"Extract / Çıkart"</b> yapın. Tebrikler, siteniz eş zamanlı olarak yayında!</li>
            </ol>
          </div>
        </div>
      </div>

      <Subscription />
      
      <div className="max-w-2xl bg-blue-50 border border-blue-100 p-6 rounded-xl space-y-2">
        <h4 className="text-blue-900 font-bold flex items-center gap-2">
          <SettingsIcon className="w-4 h-4" />
          Uygulama Bilgisi
        </h4>
        <p className="text-blue-700 text-sm">
          Bu uygulama özel olarak AI Studio ile geliştirilmiştir. 
          Tüm verileriniz Firebase bulut altyapısında güvenle saklanmaktadır.
        </p>
      </div>
    </div>
  );
};

export default Settings;
