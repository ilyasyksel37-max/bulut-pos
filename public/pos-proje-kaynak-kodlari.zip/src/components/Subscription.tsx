import React from 'react';
import { useAuth } from '../context/AuthContext';
import { CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';

export const Subscription: React.FC = () => {
  const { subscriptionStatus } = useAuth();

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900">Abonelik Yönetimi</h2>
          <p className="text-xs text-slate-500 mt-1">Mevcut planınız: <span className="font-bold text-blue-600 uppercase">{subscriptionStatus || 'Trial'}</span></p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <PlanCard 
          title="Başlangıç" 
          price="₺299" 
          features={['Hızlı Satış (POS)', 'Stok Yönetimi', 'Basit Raporlar']} 
          isActive={subscriptionStatus === 'trial'}
        />
        <PlanCard 
          title="Standart" 
          price="₺599" 
          features={['Tüm Başlangıç Özellikleri', 'Saha Sipariş Yönetimi', 'Detaylı Cari Takibi']} 
          isActive={false}
          highlight
        />
        <PlanCard 
          title="Pro" 
          price="₺999" 
          features={['Tüm Standart Özellikleri', 'Gelişmiş Prim Raporları', 'Öncelikli Destek']} 
          isActive={false}
        />
      </div>
      
      <p className="text-[10px] text-slate-400 text-center">
        * Abonelikler aylık olarak faturalandırılır. İptal etmek için destekle iletişime geçin.
      </p>
    </div>
  );
};

const PlanCard = ({ title, price, features, isActive, highlight }: any) => (
  <div className={`p-4 rounded-2xl border-2 ${highlight ? 'border-blue-600 bg-blue-50' : 'border-slate-100'} ${isActive ? 'bg-slate-50' : ''}`}>
    <h3 className="text-sm font-black text-slate-900">{title}</h3>
    <div className="text-xl font-black text-slate-950 mt-1">{price}<span className="text-xs font-bold text-slate-400">/ay</span></div>
    <ul className="mt-4 space-y-2">
      {features.map((f: string, i: number) => (
        <li key={i} className="flex items-center gap-2 text-[10px] font-bold text-slate-600">
          <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
          {f}
        </li>
      ))}
    </ul>
    <button className={`w-full mt-4 py-2 text-xs font-black rounded-xl ${isActive ? 'bg-slate-300 text-slate-600 cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-700'}`}>
      {isActive ? 'Aktif Plan' : 'Hemen Geç'}
    </button>
  </div>
);
